<?php
  const DSN = '';
  const DB_USER = '';
  const DB_PASSWORD = '';
  const AUTHORIZATION_TOKEN = '';

  function get_request_headers() {
    $headers = [];
    foreach ($_SERVER as $key => $value) {
        if (strpos($key, 'HTTP_') === 0) {
            $name = str_replace('_', '-', strtolower(substr($key, 5)));
            $headers[ucwords($name, '-')] = $value;
        }
    }
    return $headers;
  }

  $headers = get_request_headers();
  if (!isset($headers['Authorization']) || ($headers['Authorization'] !== "Bearer " . AUTHORIZATION_TOKEN)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'result' => 'Brak autoryzacji']);
    return;
  }

  $json = file_get_contents('php://input');
  $data = (object) json_decode($json, true);
  $result = null;
  $returnData = [
    'success' => false,
    'result' => null
  ];
  if (is_null($data)) {
    $returnData['result'] = 'Nie otrzymano wymaganych parametrów.';
    echo json_encode($returnData);
    return; 
  }

  try {
    if (!isset($data->allegroId) && isset($data->barcode)) { // odczyt danych
      $dbh = new PDO(DSN, DB_USER, DB_PASSWORD, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, (class_exists('Pdo\\Mysql') ? Pdo\Mysql::ATTR_FOUND_ROWS : PDO::MYSQL_ATTR_FOUND_ROWS) => true));
      $sth = $dbh->prepare('SELECT allegro_id FROM shipments_ids WHERE barcode = :barcode LIMIT 1');
      $sth->bindParam(':barcode', $data->barcode);
      $sth->execute();
      $row = $sth->fetch(PDO::FETCH_ASSOC);
      if ($row) {
        $returnData['success'] = true;
        $returnData['result'] = $row['allegro_id'];
        echo json_encode($returnData);
        return;
      }
      $returnData['success'] = true;
      $returnData['result'] = null;
      echo json_encode($returnData);
      return;
    } else if (isset($data->allegroId) && isset($data->barcode)) { // zapis danych
      $dbh = new PDO(DSN, DB_USER, DB_PASSWORD, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, (class_exists('Pdo\\Mysql') ? Pdo\Mysql::ATTR_FOUND_ROWS : PDO::MYSQL_ATTR_FOUND_ROWS) => true));
      $sth = $dbh->prepare('INSERT INTO shipments_ids (allegro_id, barcode) VALUES (:allegro_id, :barcode) ON DUPLICATE KEY UPDATE allegro_id = :allegro_id, barcode = :barcode');
      $sth->bindParam(':allegro_id', $data->allegroId);
      $sth->bindParam(':barcode', $data->barcode);
      $sth->execute(); 
      $result = $sth->rowCount();
      if (!$result) {
        $returnData['result'] = 'Błąd zapisu do bazy danych.';
        echo json_encode($returnData);
        return; 
      }
    } else {
      $returnData['result'] = 'Nie otrzymano wymaganych parametrów.';
      echo json_encode($returnData);
      return; 
    } 
  } catch (PDOException $e) {
    $returnData['result'] = "Błąd bazy danych. {$e->getMessage()}";
    echo json_encode($returnData);
    return; 
  }
 
  $returnData['success'] = true;
  $returnData['result'] = $result;
  echo json_encode($returnData);
  return; 
?>