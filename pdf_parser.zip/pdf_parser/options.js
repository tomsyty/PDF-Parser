async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromSessionStorage(data) {
	let result;
	try {
		result = await chrome.storage.session.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function saveDataToSessionStorage(data) {
	try {
		await chrome.storage.session.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

function createDownloadLink(fileContent, fileName) {
	const blob = new Blob([fileContent], { type: 'text/plain;charset=utf-8' });
	const url = URL.createObjectURL(blob);
	const link = document.createElement('a');
	link.href = url;
	link.download = fileName;
	link.style.display = 'none';
	document.body.appendChild(link);
	link.click();
	link.remove();
	URL.revokeObjectURL(url);
}

window.addEventListener('load', async () => {
	console.log('Załadowano skrypt optionsPage');
	let readedValue;
	try {
		readedValue = await readDataFromSessionStorage('message');
		if (readedValue.message !== undefined) {
			toastMessage(readedValue.message);
			await chrome.storage.session.remove('message');
		}
	} catch (error) {
		toastMessage(`Błąd! Nie udało się sprawdzić czy istnieje wiadomość którą należy wyświetlić albo nie udało się jej usunąć po jej wyświetleniu. ${getErrorMessage(error)}`);
	}

  try {
    readedValue = await readDataFromLocalStorage(['protocolSelector', 'shipmentsPhpFilePath', 'authorizationToken', 'dbDSN', 'dbUser', 'dbPassword', 'debugMode']);
    const protocolSelector = document.getElementById('protocolSelector');
    if (readedValue.protocolSelector === 'http://') protocolSelector.selectedIndex = 1;

    const phpFilePathInput = document.getElementById('phpFilePathInput');
    phpFilePathInput.value = readedValue.shipmentsPhpFilePath || '';

    const phpPathInputSaveButton = document.getElementById('phpPathInputSaveButton');
    phpPathInputSaveButton.addEventListener('click', async () => {
      const protocolSelector = document.getElementById('protocolSelector');
      const phpFilePathInput = document.getElementById('phpFilePathInput');
      try {
        await saveDataToLocalStorage({ protocolSelector: protocolSelector.value, shipmentsPhpFilePath: phpFilePathInput.value });
        toastMessage('Zapisano');
        await sendMessage({ action: 'loadDefaultValues' });
      } catch (error) {
        toastMessage(`Błąd! Podczas zapisu danych wystąpił błąd. ${getErrorMessage}`);
      }
    });

    const authorizationTokenToggleMaskSpan = document.getElementById('authorizationTokenToggleMaskSpan');
    authorizationTokenToggleMaskSpan.addEventListener('click', (event) => passwordInputToggleVisibilitySpanClick(event, 'authorizationTokenInput'));

    const authorizationTokenInput = document.getElementById('authorizationTokenInput');
    authorizationTokenInput.value = readedValue.authorizationToken || '';

    const authorizationTokenGenerateRandomButton = document.getElementById('authorizationTokenGenerateRandomButton');
    authorizationTokenGenerateRandomButton.addEventListener('click', async () => {
      const authorizationTokenToggleMaskSpan = document.getElementById('authorizationTokenToggleMaskSpan');
      const authorizationTokenInput = document.getElementById('authorizationTokenInput');
      authorizationTokenInput.value = generateRandomString();
      authorizationTokenToggleMaskSpan.innerText = 'pokaż';
      authorizationTokenToggleMaskSpan.dispatchEvent(new Event('click'));
    });

    const dbDSNInput = document.getElementById('dbDSNInput');
    dbDSNInput.value = readedValue.dbDSN || '';

    const dbUserInput = document.getElementById('dbUserInput');
    dbUserInput.value = readedValue.dbUser || '';

    const dbPasswordToggleMaskSpan = document.getElementById('dbPasswordToggleMaskSpan');
    dbPasswordToggleMaskSpan.addEventListener('click', (event) => passwordInputToggleVisibilitySpanClick(event, 'dbPasswordInput'));

    const dbPasswordInput = document.getElementById('dbPasswordInput');
    dbPasswordInput.value = readedValue.dbPassword || '';

    const parametersSaveButton = document.getElementById('parametersSaveButton');
    parametersSaveButton.addEventListener('click', async () => {
      const authorizationTokenInput = document.getElementById('authorizationTokenInput');
       try {
        await saveDataToLocalStorage({ authorizationToken: authorizationTokenInput.value, dbDSN: dbDSNInput.value, dbUser: dbUserInput.value, dbPassword: dbPasswordInput.value });
        toastMessage('Zapisano');
        const response = await fetch(chrome.runtime.getURL('shipments_ids_template.php'));
        if (response.ok) {
          const fileContent = await response.text();
          let updatedFileContent = fileContent.replace(/const DSN = .*/, `const DSN = '${dbDSNInput.value}';`);
          updatedFileContent = updatedFileContent.replace(/const DB_USER = .*/, `const DB_USER = '${dbUserInput.value}';`);
          updatedFileContent = updatedFileContent.replace(/const DB_PASSWORD = .*/, `const DB_PASSWORD = '${dbPasswordInput.value}';`);
          updatedFileContent = updatedFileContent.replace(/const AUTHORIZATION_TOKEN = .*/, `const AUTHORIZATION_TOKEN = '${authorizationTokenInput.value}';`);
          createDownloadLink(updatedFileContent, 'shipments_ids.php');
          toastMessage('Zapisano zmiany w pliku i pobrano plik');
          await sendMessage({ action: 'loadDefaultValues' });
        } else throw new Error('Nie udało się odczytać pliku "shipments_ids.php" w którym mają zostać zapisane zmiany.');
      } catch (error) {
        toastMessage(`Błąd! Podczas zapisu danych wystąpił błąd. ${getErrorMessage}`);
      }
    });

    const debugCheckbox = document.getElementById('debugCheckbox');
    debugCheckbox.checked = readedValue.debugMode || false;
    debugCheckbox.addEventListener('change', async (e) => {
      try {
			  await saveDataToLocalStorage({ debugMode: e.target.checked });
		  } catch (error) {
			  toastMessage(`Błąd! Nie udało się zmienić ustawień dotyczących trybu debugowania. ${getErrorMessage(error)}`);
			  return Promise.reject(false);
		  }
		  toastMessage('Zapisano');
    });
  } catch (error) {
    toastMessage(`Błąd! Podczas odczytu danych zapisanych w pamięci nastąpił błąd. ${getErrorMessage}`);
  }
});

function passwordInputToggleVisibilitySpanClick(e, inputElement) {
  if (e.target.innerText === 'ukryj') {
    e.target.innerText = 'pokaż';
    document.getElementById(inputElement).type = 'password';
  } else {
    e.target.innerText = 'ukryj';
    document.getElementById(inputElement).type = 'text';
  }
}

function generateRandomString() {
  let result = '';

  const length = Math.floor(Math.random() * (64 - 32 + 1) + 16);
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{};:,.?';
  const charactersLength = characters.length;
  for ( let i = 0; i < length; i++ ) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}