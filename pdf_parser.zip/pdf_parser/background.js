console.log('Załadowano rozszerzenie PDF Parser');

async function saveDataToLocalStorage(data) {
	try {
		await chrome.storage.local.set(data);
		return Promise.resolve(true);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

function optionsPageMessage(textMessage) {
	chrome.storage.session.set({ message: textMessage }).then(() => {
		chrome.runtime.openOptionsPage();
	});
}

chrome.runtime.onInstalled.addListener(details => {
	if (details.reason === 'install') {
		console.log('Ustawianie domyślnych wartości...');
		chrome.storage.local.set({
			protocolSelector: 'https://',
			shipmentsPhpFilePath: '',
			authorizationToken: '',
			dbDSN: '',
			dbUser: '',
			dbPassword: '',
			debugMode: false,
			updateLastChecked: ''
		}).then(() => {
			optionsPageMessage('Uwaga! Uzupełnij parametry wymagane do działania rozszerzenia.');
		}).catch(error => {
			console.log(error.message);
		});
	}
});

let protocolSelector, shipmentsPhpFilePath, authorizationToken;

(async () => {
	try {
		readedValue = await readDataFromLocalStorage(['protocolSelector', 'shipmentsPhpFilePath', 'authorizationToken']);
		protocolSelector = readedValue.protocolSelector || '';
		shipmentsPhpFilePath = readedValue.shipmentsPhpFilePath || '';
		authorizationToken = readedValue.authorizationToken || '';
	} catch (error) {
		optionsPageMessage('Błąd! Nie udało się odczytać wartości konfiguracyjnych wymaganych przez program.');
	}
})();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
	asyncOnMessageCallback(request, sender).then(resolved => { sendResponse({ success: true, result: resolved }) }).catch(rejected => { sendResponse({ success: false, result: rejected }) });
	return true;
});

function getErrorMessage(error) {
  if (error?.message) return error.message;
  if (typeof error === 'string') return error;
  return JSON.stringify(error);
}

async function asyncOnMessageCallback(request, sender) {
	const action = request.action;
	switch (action) {
		case 'loadDefaultValues': {
			let readedValue;
			try {
				readedValue = await readDataFromLocalStorage(['protocolSelector', 'shipmentsPhpFilePath', 'authorizationToken']);
				protocolSelector = readedValue.protocolSelector;
				shipmentsPhpFilePath = readedValue.shipmentsPhpFilePath;
				authorizationToken = readedValue.authorizationToken;
			} catch (error) {
				optionsPageMessage('Błąd! Nie udało się odczytać wartości konfiguracyjnych wymaganych przez program.');
			}
		}

    case 'saveShipmentsIds': {
      let fetchResponse;
			try {
				fetchResponse = await fetch(`${protocolSelector}${shipmentsPhpFilePath}/shipments_ids.php`, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + authorizationToken
					},
					body: JSON.stringify({
            'allegroId': request.allegroId,
            'barcode': request.barcode
          })
				});
			} catch (error) {	
				return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Dane o przesyłce nie zostały przesłane.`);
			}
		
			if (fetchResponse.status !== 200) return Promise.reject(`Dane o przesyłce nie zostały przesłane. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
			return Promise.resolve(true);
    }

    case 'readShipmentsIds': {
      let fetchResponse;
			try {
				fetchResponse = await fetch(`${protocolSelector}${shipmentsPhpFilePath}/shipments_ids.php`, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + authorizationToken
					},
					body: JSON.stringify({
            'barcode': request.barcode
          })
				});
			} catch (error) {	
				return Promise.reject(`Podczas wysyłania żądania wystąpił błąd. Dane o przesyłce nie zostały odebrane.`);
			}

			if (fetchResponse.status === 200) {
				let result;
				try {
					result = await fetchResponse.json();
					if (result.success === true) return Promise.resolve(result.result)
				} catch (error) {
					return Promise.reject(`Podczas dekodowania odpowiedzi serwera wystąpił błąd. ${getErrorMessage(error)}`);
				}
				return Promise.resolve(result);
			}
		
			if (fetchResponse.status !== 200) return Promise.reject(`Dane o przesyłce nie zostały odebrane. Kod odpowiedzi HTTP: ${fetchResponse.status}`);
    }

		case 'downloadLabel': {
			async function waitForDownloadFinished() {
				return new Promise((resolve, reject) => {
					let downloadItemId = 0;
					let timeoutId = setTimeout(() => {
						chrome.downloads.onChanged.removeListener(downloadEvent);
						reject('Upłynął czas na pobieranie pliku.');
					}, 10000);
					function downloadEvent(downloadItem) {
						console.log('Wykryto zdarzenie pobierania.');
						if (downloadItemId === 0) {
							chrome.downloads.search({
								state: 'in_progress',
								mime: 'application/pdf',
								finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
								limit: 1,
								orderBy: ["-startTime"],
							}).then(downloadSearchResult => {
								if (downloadSearchResult.length) {
									downloadItemId = downloadSearchResult[0].id;
								}
							}).catch(error => {
								console.log(`Błąd podczas pobierania etykiety. ${error.message}`);
							});
						}
						if (downloadItem.state !== undefined && downloadItem.state.current === 'complete' && downloadItem.id === downloadItemId) {
							console.log('Zakończono pobieranie.');
							chrome.downloads.onChanged.removeListener(downloadEvent);
							clearTimeout(timeoutId);
							chrome.downloads.search({
								state: 'complete',
								exists: true,
								mime: 'application/pdf',
								finalUrlRegex: '^blob:https://salescenter.allegro.com|(.allegrosandbox.pl)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{10}',
								limit: 1,
								id: downloadItemId
							}).then(downloadSearchResult => {
								if (downloadSearchResult.length) {
									resolve({ filename: './downloads/' + downloadSearchResult[0].filename.slice(downloadSearchResult[0].filename.lastIndexOf('\\') + 1), id: downloadSearchResult[0].id });
								} else {
									reject('Nie znaleziono pobranego pliku.');
								}
							}).catch(error => {
								console.log(`Błąd podczas pobierania etykiety. ${error.message}`);
								reject(`Błąd podczas pobierania etykiety. ${error.message}`);
							});
						}
					}
					chrome.downloads.onChanged.addListener(downloadEvent);
				});
			}
			return await waitForDownloadFinished();
		}
  }
}

(async function checkUpdate() {
	let readedValue;
	try {
		readedValue = await readDataFromLocalStorage(['updateLastChecked']);
	} catch (error) {
		optionsPageMessage(`Błąd! Podczas odczytu daty ostatniego sprawdzania aktualizacji wystąpił błąd. ${getErrorMessage(error)}`);
		return;
	}
	if (!readedValue.updateLastChecked) {
		const currentDate = new Date();
		readedValue.updateLastChecked = currentDate.toString();
		try {
			await saveDataToLocalStorage({ updateLastChecked: readedValue.updateLastChecked });
			return;
		} catch (error) {
			optionsPageMessage(`Błąd! Podczas zapisu daty ostatniego sprawdzania aktualizacji wystąpił błąd. ${getErrorMessage(error)}`);
			return;
		}
	}

	const currentDate = new Date();
	const lastChecked = new Date(readedValue.updateLastChecked);

	const msDifference = currentDate - lastChecked;
	const msIn24Hours = 24 * 60 * 60 * 1000;

	if (msDifference >= msIn24Hours) {
		try {
			await saveDataToLocalStorage({ updateLastChecked: currentDate.toString() });
		} catch (error) {
			optionsPageMessage(`Błąd! Podczas zapisu daty ostatniego sprawdzania aktualizacji wystąpił błąd. ${getErrorMessage(error)}`);
			return;
		}
	} else {
		console.log('Nie minęły 24h od ostatniego sprawdzania aktualizacji. Pomijam sprawdzanie aktualizacji.');
		return;
	}
	let fetchResponse;
	try {
		fetchResponse = await fetch('https:/raw.githubusercontent.com/tomsyty/PDF-Parser/main/current-version');
	} catch (error) {
		const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
		if (notificationsAllowed) {
			chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
				if (buttonIndex === 0) {
					chrome.tabs.create({ url: 'https://github.com/tomsyty/PDF-Parser' }).catch(() => {});
				}
			});
			chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: ` Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". Sprawdź wersję ręcznie na stronie rozszerzenia.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true }).catch(() => {});
		} else {
			optionsPageMessage(`Błąd! Nie udało się sprawdzić aktualizacji rozszerzenia "${chrome.runtime.getManifest().name}". ${error.message}`);
		}
		return;
	}

	if (fetchResponse.status === 200) {
		const currentVersion = await fetchResponse.text();
		if (currentVersion.trim() !== chrome.runtime.getManifest().version) {
			const notificationsAllowed = await chrome.permissions.contains({ permissions: ['notifications'] });
			if (notificationsAllowed) {
				chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
					if (buttonIndex === 0) {
						chrome.tabs.create({ url: 'https://github.com/tomsyty/PDF-Parser' }).catch(() => {});
					}
				});
				chrome.notifications.create('', { type: 'basic', iconUrl: 'info_48x48.png', title: 'Aktualizacja rozszerzenia', message: `Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`, buttons: [{ title: 'Otwórz stronę rozszerzenia' }], silent: true }).catch(() => {});
			} else {
				optionsPageMessage(`Znaleziono nową wersję rozszerzenia "${chrome.runtime.getManifest().name}". Pobierz ją i zainstaluj ręcznie.`);
			}
		}
	} else {
		console.log('Brak pliku z informacją o aktualizacji');
	}
})();
