async function readDataFromLocalStorage(data) {
	let result;
	try {
		result = await chrome.storage.local.get(data);
		return Promise.resolve(result);
	} catch (error) {
		return Promise.reject(error);
	}
}

async function sendMessage(data) {
	let response;
	try {
		response = await chrome.runtime.sendMessage(data);
		return Promise.resolve(response);
	} catch (error) {
		return Promise.reject(error);
	}
}

let kbdTimeoutId;

function loadPdfParse() {
  return new Promise((resolve, reject) => {
    const existing = document.getElementById('pdfParserScript');

    const finish = () => {
      const PDFParse = window.PdfParse?.PDFParse || window.PdfParse;
      if (typeof PDFParse === 'function') {
        resolve(PDFParse);
      } else {
        reject(new Error('Błąd ładowania PDF Parser (1).'));
      }
    };

    if (existing) {
      if (window.PdfParse?.PDFParse || window.PdfParse) {
        finish();
      } else {
        existing.addEventListener('load', finish, { once: true });
        existing.addEventListener('error', () => reject(new Error('Błąd ładowania PDF Parser (2).')), { once: true });
      }
      return;
    }

    const script = document.createElement('script');
    script.id = 'pdfParserScript';
    script.src = chrome.runtime.getURL('pdf-parse.umd.js');
    script.onload = finish;
    script.onerror = () => reject(new Error('Błąd ładowania PDF Parser (3).'));
    (document.head || document.documentElement).appendChild(script);
  });
}

async function extractText(fileName) {
  const localFile = fileName.trim().replace(/^\/+/, '');
  const localUrl = chrome.runtime.getURL(localFile);
  let response;
  try {
    response = await fetch(localUrl, { credentials: 'omit' });
    if (!response.ok) {
      throw new Error(`Błąd ładowania pliku pdf: ${response.status}`);
    }
  } catch (error) {
    return Promise.reject(error.message);
  }

  let arrayBuffer;

  try {
    arrayBuffer = await response.arrayBuffer();
  } catch (error) {
    return Promise.reject(`Błąd buforowania danych. ${getErrorMessage(error)}`); 
  }

  const data = new Uint8Array(arrayBuffer);
  let PDFParse; 
  try { 
    PDFParse = await loadPdfParse();
  } catch (error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
  }

  if (typeof PDFParse.setWorker === 'function') {
    PDFParse.setWorker(chrome.runtime.getURL('pdf.worker.mjs'));
  }

  const parser = new PDFParse({ data });

  try {
    const result = await parser.getText({ pageJoiner: '<EndOfPage>' });
    return result.text;
  } catch(error) {
    toastMessage(`Błąd! ${getErrorMessage(error)}`);
  } finally {
    await parser.destroy().catch(() => {});
  }
}

let pdfParserDebugMode = false;

window.addEventListener('load', async () => {
  console.log('Załadowano skrypt PDF Parser'); 

  let readedValue;
  try {
    readedValue = await readDataFromLocalStorage(['debugMode']);
    pdfParserDebugMode = readedValue.debugMode;
  } catch (error) {
    toastMessage(`Błąd! Nie udało się odczytać informacji dotyczących trybu debugowania. Nie będzie miał on zastosowania.`);
  }

  let previousUrl;
  let observer;
	const urlObserver = new MutationObserver(async () => {
		if (window.location.href !== previousUrl) {
			previousUrl = window.location.href;
			await new Promise(resolve => setTimeout(resolve, 100));
      if (window.location.href.search(/https:\/\/salescenter\.allegro\.com(?:\.allegrosandbox\.pl|)\/ship-with-allegro\/swa\/create-shipment-status/) === 0) {
        (async function findDownloadButton() {
          const downloadButton = Array.from(document.querySelectorAll('button:enabled')).find(element => element.textContent === 'Pobierz etykietę');
          if (downloadButton !== undefined) {
             const shippingMethodCell = Array.from(document.querySelectorAll('th')).find(element => element.innerText === 'Metoda dostawy');
            if (shippingMethodCell !== undefined) {
              const shippingMethod = shippingMethodCell?.parentNode?.parentNode?.nextElementSibling?.firstChild?.childNodes?.[shippingMethodCell.cellIndex]?.innerText;
              if (['Allegro Automat ORLEN Paczka', 'Allegro Odbiór w Punkcie ORLEN Paczka', 'Allegro Automat DHL BOX 24/7 (AD)', 'Allegro Odbiór w Punkcie DHL (AD)', 'Allegro Kurier DHL (AD)', 'Allegro Automaty Paczkowe DPD (AD)', 'Allegro Odbiór w Punkcie DPD Pickup (AD)', 'Allegro Odbiór w Punkcie DPD Pickup pobranie (AD)', 'Allegro Kurier DPD (AD)', 'Allegro Kurier DPD pobranie (AD)', 'Allegro One Box, DPD', 'Allegro One Punkt, DPD'].indexOf(shippingMethod) === -1) return;
              downloadButton.addEventListener('click', pdfParserDownloadLabelButtonClick);
              downloadButton.style.backgroundColor = 'lightgreen';
            }
          } else {
            const delay = t => new Promise(resolve => setTimeout(resolve, t));
            await delay(100);
            return await findDownloadButton();
          }
        })();
      } else if (window.location.href.search(/https:\/\/salescenter\.allegro\.com(?:\.allegrosandbox\.pl|)\/orders\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/) === 0) { 
        let delayedCheck = setTimeout(() => {
          const downloadButtons = Array.from(document.querySelectorAll('button:enabled')).filter(button =>button.textContent === 'DRUKUJ ETYKIETĘ');
          if (downloadButtons.length) {
            observer.disconnect();
            downloadButtons.forEach(downloadButton => {
              if (!downloadButton) return;
              let shippingMethod = Array.from(downloadButton.closest('div[data-box-name="allegro.wza.order.details.packages"]')?.querySelectorAll('div')).find(element => element.textContent === 'PRZEWOŹNIK I NUMER PRZESYŁKI');
              if (shippingMethod) {
                shippingMethod = shippingMethod?.nextElementSibling?.innerText?.split('\n')[0];
                if (shippingMethod && ['Allegro Automat ORLEN Paczka', 'Allegro Odbiór w Punkcie ORLEN Paczka', 'Allegro Automat DHL BOX 24/7 (AD)', 'Allegro Odbiór w Punkcie DHL (AD)', 'Allegro Kurier DHL (AD)', 'Allegro Automaty Paczkowe DPD (AD)', 'Allegro Odbiór w Punkcie DPD Pickup (AD)', 'Allegro Odbiór w Punkcie DPD Pickup pobranie (AD)', 'Allegro Kurier DPD (AD)', 'Allegro Kurier DPD pobranie (AD)', 'Allegro One Box, DPD', 'Allegro One Punkt, DPD'].indexOf(shippingMethod) === -1) return;
                downloadButton.addEventListener('click', pdfParserDownloadLabelButtonClick);
                downloadButton.style.backgroundColor = 'lightgreen';
              }
            });
            console.log('Znaleziono przycisk - timeout (1)');
          }
        }, 1000); 

        observer = new MutationObserver(mutations => {
          mutations.forEach(mutation => {
            if (mutation.type === 'childList' && mutation.target.nodeName === 'DIV') {
              mutation.addedNodes.forEach(node => {
                if (!node) return;
                const downloadButton = Array.from(node.querySelectorAll('button:enabled')).find(element => {
                  if (element.textContent === 'DRUKUJ ETYKIETĘ') return true;
                  return false;
                });
                if (downloadButton) {
                  clearTimeout(delayedCheck);
                  observer.disconnect();
                  let shippingMethod = Array.from(downloadButton.closest('div[data-box-name="allegro.wza.order.details.packages"]')?.querySelectorAll('div')).find(element => element.textContent === 'PRZEWOŹNIK I NUMER PRZESYŁKI');
                  if (shippingMethod) {
                    shippingMethod = shippingMethod?.nextElementSibling?.innerText?.split('\n')[0];
                    if (shippingMethod && ['Allegro Automat ORLEN Paczka', 'Allegro Odbiór w Punkcie ORLEN Paczka', 'Allegro Automat DHL BOX 24/7 (AD)', 'Allegro Odbiór w Punkcie DHL (AD)', 'Allegro Kurier DHL (AD)', 'Allegro Automaty Paczkowe DPD (AD)', 'Allegro Odbiór w Punkcie DPD Pickup (AD)', 'Allegro Odbiór w Punkcie DPD Pickup pobranie (AD)', 'Allegro Kurier DPD (AD)', 'Allegro Kurier DPD pobranie (AD)', 'Allegro One Box, DPD', 'Allegro One Punkt, DPD'].indexOf(shippingMethod) === -1) return;
                    downloadButton.addEventListener('click', pdfParserDownloadLabelButtonClick);
                    downloadButton.style.backgroundColor = 'lightgreen';
                  }
                  console.log('Znaleziono przycisk - observer (1)');
                }
              });
            }
          });
        });
        const observedElement = document.querySelector('div[data-box-name="allegro.wza.order.details.packages"]');
        observer.observe(observedElement, { subtree: true, childList: true });  
      } else if (window.location.href.search(/https:\/\/salescenter\.allegro\.com(?:\.allegrosandbox\.pl|)\/ship-with-allegro\/shipments/) === 0) {
        function findDownloadButton() {
          let downloadButton = Array.from(document.querySelectorAll('button')).find(element => element.textContent === 'Etykiety');
          if (downloadButton) {
            observer.disconnect();
            let shippingMethod = Array.from(downloadButton.closest('tr')?.querySelectorAll('p')??[]).find(e => e.textContent.indexOf('Szczegóły paczki') === 0);
            if (shippingMethod) {
              shippingMethod = Array.from(downloadButton.closest('tr')?.previousElementSibling?.querySelectorAll('div')).find(e => e.textContent === 'Metoda dostawy')?.nextSibling?.textContent;
              if (shippingMethod && ['Allegro Automat ORLEN Paczka', 'Allegro Odbiór w Punkcie ORLEN Paczka', 'Allegro Automat DHL BOX 24/7 (AD)', 'Allegro Odbiór w Punkcie DHL (AD)', 'Allegro Kurier DHL (AD)', 'Allegro Automaty Paczkowe DPD (AD)', 'Allegro Odbiór w Punkcie DPD Pickup (AD)', 'Allegro Odbiór w Punkcie DPD Pickup pobranie (AD)', 'Allegro Kurier DPD (AD)', 'Allegro Kurier DPD pobranie (AD)', 'Allegro One Box, DPD', 'Allegro One Punkt, DPD'].indexOf(shippingMethod) === -1) return;
              downloadButton.addEventListener('click', pdfParserDownloadLabelButtonClick);
              downloadButton.style.backgroundColor = 'lightgreen';
              console.log('Znaleziono przycisk - timeout (2)');
              return true;
            }      
          }
          return false;
        }

        let delayedCheck = setTimeout(() => {
          findDownloadButton();
        }, 1000);

        const observer = new MutationObserver(mutations => {
          mutations.forEach(mutation => {
            if (mutation.type === 'childList' && mutation.target.nodeName === 'DIV') {
              mutation.addedNodes.forEach(node => {
                if (!node) return;
                if (node.innerText.startsWith('SZCZEGÓŁY PACZKI')) {
                  let shippingMethod = Array.from(document.querySelectorAll('p')).find(e => e.textContent.indexOf('Szczegóły paczki') === 0);
                  if (shippingMethod) {
                    shippingMethod = Array.from(shippingMethod.closest('tr')?.previousElementSibling?.querySelectorAll('div')).find(e => e.textContent === 'Metoda dostawy')?.nextSibling?.textContent;
                    if (shippingMethod) {
                      observer.disconnect();
                      if (shippingMethod && ['Allegro Automat ORLEN Paczka', 'Allegro Odbiór w Punkcie ORLEN Paczka', 'Allegro Automat DHL BOX 24/7 (AD)', 'Allegro Odbiór w Punkcie DHL (AD)', 'Allegro Kurier DHL (AD)', 'Allegro Automaty Paczkowe DPD (AD)', 'Allegro Odbiór w Punkcie DPD Pickup (AD)', 'Allegro Odbiór w Punkcie DPD Pickup pobranie (AD)', 'Allegro Kurier DPD (AD)', 'Allegro Kurier DPD pobranie (AD)', 'Allegro One Box, DPD', 'Allegro One Punkt, DPD'].indexOf(shippingMethod) === -1) return;
                      clearTimeout(delayedCheck);
                      console.log('Znaleziono przycisk - observer (2)');

                      if (!findDownloadButton()) {
                        (async () => {
                          const delay = t => new Promise(resolve => setTimeout(resolve, t));
                          await delay(500);
                          findDownloadButton();
                        });
                      }
                    }
                  }	
                }
              });
            }
          });
        });
        observer.observe(document.body, { subtree: true, childList: true });

        let shipmentsTable = document.querySelector('table');
        if (!shipmentsTable) {
          await new Promise(resolve => setTimeout(resolve, 2000)); 
          shipmentsTable = document.querySelector('table');
          if (!shipmentsTable) {
            toastMessage('Błąd! Nie znaleziono tabeli z listą przesyłek.');
            return;
          }
        }
        let checkboxes = shipmentsTable.querySelectorAll('input[name="shipmentSelect"]');
        checkboxes.forEach(checkbox => {
          checkbox.addEventListener('change', pdfParserCheckboxChange);
        });
        let checkboxSelectAll = document.getElementById('shipmentSelector');
        checkboxSelectAll.addEventListener('change', pdfParserCheckboxChange);

      }	else if (window.location.href.search(/https:\/\/salescenter\.allegro\.com(?:\.allegrosandbox\.pl|)\/orders/) === 0)	{
        await new Promise(resolve => setTimeout(resolve, 100));
        let searchBox = document.getElementById('search_filter');
        if (!searchBox) {
          let retriesLeft = 50;
          while (!searchBox && --retriesLeft) {
            await new Promise(resolve => setTimeout(resolve, 200));
            searchBox = document.getElementById('search_filter');
          }
        }
        if (!searchBox) {
          toastMessage('Uwaga! Nie znaleziono pola wyszukiwania, skanowanie kodów nie będzie aktywowane.');
          return;
        }

        if (!document.getElementById('barcodeIcon')) {
          searchBox.parentElement.insertAdjacentHTML('afterbegin', '<span id="barcodeIcon" class="material-symbols-outlined" style="position: absolute; transform: translateY(-25px); z-index: 2; cursor: default;">barcode</span>');
          searchBox.addEventListener('input', checkBarcode.bind(null, searchBox)); 
        }
      }
		}
	});
	urlObserver.observe(document, { subtree: true, childList: true });
});

async function pdfParserCheckboxChange(e) {
  const	groupOperationsBar = Array.from(document.querySelectorAll('div[class~="mp7g_ca"]')).find(element => element.textContent.indexOf('podjazdDrukujEtykiety') === -1);
  if (!groupOperationsBar) return;
  await new Promise(resolve => setTimeout(resolve, 100));
  const pdfParserDownloadAllLabelsButton = document.querySelector('button[data-analytics-interaction-label="wza_shipments_listing_action_bar_labels_download_click"]');

  const shippingMethods = [
    'Allegro Automat ORLEN Paczka',
    'Allegro Odbiór w Punkcie ORLEN Paczka',
    'Allegro Automat DHL BOX 24/7 (AD)',
    'Allegro Odbiór w Punkcie DHL (AD)',
    'Allegro Kurier DHL (AD)',
    'Allegro Automaty Paczkowe DPD (AD)',
    'Allegro Odbiór w Punkcie DPD Pickup (AD)',
    'Allegro Odbiór w Punkcie DPD Pickup pobranie (AD)',
    'Allegro Kurier DPD (AD)',
    'Allegro Kurier DPD pobranie (AD)',
    'Allegro One Box, DPD',
    'Allegro One Punkt, DPD'
  ];

  const checkedCheckboxes = Array.from(document.querySelectorAll('input[name="shipmentSelect"]:checked'));
  const result = checkedCheckboxes.some(checkbox => {
    const shipmentRow = checkbox.closest('tr');
    if (!shipmentRow) return false;

    const selectedShippingMethod = shipmentRow.cells?.[3]?.outerText;
    if (!selectedShippingMethod) return false;
    return (shippingMethods.indexOf(selectedShippingMethod) === -1 ? false : true);
  });

  if (result) {
    pdfParserDownloadAllLabelsButton.addEventListener('click', pdfParserDownloadLabelButtonClick);
    pdfParserDownloadAllLabelsButton.style.backgroundColor = 'lightgreen';
  } else {
    if (pdfParserDownloadAllLabelsButton) pdfParserDownloadAllLabelsButton.style.backgroundColor = 'initial';
  }
}

async function checkBarcode(searchBox) {
  clearTimeout(kbdTimeoutId);
  const query = searchBox.value;
  if (query.length > 12) {
    kbdTimeoutId = setTimeout(async () => {
      let response;
      response = await sendMessage({ action: 'readShipmentsIds', barcode: query });
      if (response.success && response.result) {
        searchBox.value = response.result;
        searchBox.dispatchEvent(new InputEvent('input', { bubbles: true }));
      }
    }, 300);
  }
}

async function pdfParserDownloadLabelButtonClick() {
  let response;
  try {
    response = await sendMessage({ action: 'downloadLabel' });
    if (response.success === false) throw new Error(response.result);
  } catch (error) {
    console.log(`Błąd podczas pobierania etykiety. ${(error instanceof Error ? error.message : error)}`);
    return; 
  }

  if (response.result?.filename !== undefined && response.result?.id !== undefined) {
    try {
      await pdfParserProcessPDF(response.result.filename, response.result.id);
    } catch (error) {
      toastMessage(`Błąd! ${getErrorMessage(error)}`);
      return;
    }
  } else {
    toastMessage('Błąd! Plik nie zostanie przetworzony.');
  }
}

async function pdfParserProcessPDF(filename, id) {
  let response;
  let fullText;
  try {
    fullText = await extractText(filename);
  } catch (error) {
    return Promise.reject(error);
  }

  const pages = fullText.split('<EndOfPage>');
  pages.pop();
  console.log('Znaleziono stron: ' + pages.length);
  pages.forEach(async (page) => {
    page = page.trim();
    if (pdfParserDebugMode) {
      console.log(page);
      toastMessage('Włączone debugowanie etykiet, otwórz konsolę dewelopera (F12)');
    }
    if (page.indexOf('TYP POK') !== -1) {
      console.log('Znaleziono etykietę Orlen Paczka');
      const arrayOfLines = page.split('\n');
      let index = 0;
      let allegroParcelNumber = '';
      let carrierParcelNumber = '';
      const maxIndex = arrayOfLines.length;
      do {
        if (arrayOfLines[index].indexOf('Numer paczki:') !== -1) {
          carrierParcelNumber = arrayOfLines[index + 1];
        }
        if (arrayOfLines[index].indexOf('Numer Allegro:') !== -1) {
          allegroParcelNumber = arrayOfLines[index].split(':')[1].trim();
          break;
        }
        index++;
      } while (index < maxIndex);
      if (allegroParcelNumber && carrierParcelNumber) {
        console.log(`Numer przesyłki Allegro: ${allegroParcelNumber}, kod kreskowy: ${carrierParcelNumber}`);

        try {
          response = await sendMessage({ action: 'saveShipmentsIds', allegroId: allegroParcelNumber, barcode: carrierParcelNumber });
          if (!response.success) throw new Error(response.result);
        } catch (error) {
          return Promise.reject(`Podczas zapisywania numerów przesyłek w bazie danych wystąpił błąd. ${getErrorMessage(error)}`);
        }

      } else {
        console.log(page);
        return Promise.reject('Błąd! Nie znaleziono numeru przesyłki Allegro / kodu kreskowego.');
      }
    } else if (page.indexOf('DHL eCommerce') !== -1) {
      console.log('Znaleziono etykietę DHL');
      const arrayOfLines = page.split('\n');
      let index = 0;
      let allegroParcelNumber = '';
      let carrierParcelNumber = '';
      const maxIndex = arrayOfLines.length;
      do {
        if (arrayOfLines[index].indexOf('Nr Allegro:') !== -1) {
          allegroParcelNumber = arrayOfLines[index].split(':')[1].trim();
          carrierParcelNumber = arrayOfLines[index + 1].replace(/[\(\)\s]/g, '');
          break;
        }
        index++;
      } while (index < maxIndex);
      if (allegroParcelNumber && carrierParcelNumber) {
        console.log(`Numer przesyłki Allegro: ${allegroParcelNumber}, kod kreskowy: ${carrierParcelNumber}`);

        try {
          response = await sendMessage({ action: 'saveShipmentsIds', allegroId: allegroParcelNumber, barcode: carrierParcelNumber });
          if (!response.success) throw new Error(response.result);
        } catch (error) {
          return Promise.reject(`Podczas zapisywania numerów przesyłek w bazie danych wystąpił błąd. ${getErrorMessage(error)}`);
        }

      } else {
        console.log(page);
        return Promise.reject('Błąd! Nie znaleziono numeru przesyłki Allegro / kodu kreskowego.');
      }
    } else if (page.indexOf('przez DPD Polska') !== -1) {
      console.log('Znaleziono etykietę Allegro One DPD');
      const arrayOfLines = page.split('\n');
      let index = 0;
      let allegroParcelNumber = '';
      let carrierParcelNumber = '';
      const maxIndex = arrayOfLines.length;
      do {
        if (arrayOfLines[index] === 'Adres doręczenia') {
          allegroParcelNumber = arrayOfLines[index + 1];
          carrierParcelNumber = arrayOfLines[maxIndex - 1].replace(/\s/g, '');
          carrierParcelNumber = carrierParcelNumber.substring(0, carrierParcelNumber.length - 1);
          break;
        }
        index++;
      } while (index < maxIndex);
      if (allegroParcelNumber && carrierParcelNumber) {
        console.log(`Numer przesyłki Allegro: ${allegroParcelNumber}, kod kreskowy: ${carrierParcelNumber}`);

        try {
          response = await sendMessage({ action: 'saveShipmentsIds', allegroId: allegroParcelNumber, barcode: carrierParcelNumber });
          if (!response.success) throw new Error(response.result);
        } catch (error) {
          return Promise.reject(`Podczas zapisywania numerów przesyłek w bazie danych wystąpił błąd. ${getErrorMessage(error)}`);
        }

      } else {
        console.log(page);
        return Promise.reject('Błąd! Nie znaleziono numeru przesyłki Allegro / kodu kreskowego.');
      }
    } else if (page.indexOf('DPD Polska Sp. z o.o. Więcej') !== -1) {
      console.log('Znaleziono etykietę DPD');
      const arrayOfLines = page.split('\n');
      let index = 0;
      let allegroParcelNumber = '';
      let carrierParcelNumber = '';
      const maxIndex = arrayOfLines.length;
      do {
        if (arrayOfLines[index] === 'NADAWCA\t') {
          allegroParcelNumber = arrayOfLines[index - 1].replace(/\s/g, '');
          carrierParcelNumber = arrayOfLines[maxIndex - 1].replace(/\s/g, '');
          carrierParcelNumber = carrierParcelNumber.substring(0, carrierParcelNumber.length - 1);
          break;
        } 
        index++;
      } while (index < maxIndex);
      if (allegroParcelNumber && carrierParcelNumber) {
        console.log(`Numer przesyłki Allegro: ${allegroParcelNumber}, kod kreskowy: ${carrierParcelNumber}`);

        try {
          response = await sendMessage({ action: 'saveShipmentsIds', allegroId: allegroParcelNumber, barcode: carrierParcelNumber });
          if (!response.success) throw new Error(response.result);
        } catch (error) {
          return Promise.reject(`Podczas zapisywania numerów przesyłek w bazie danych wystąpił błąd. ${getErrorMessage(error)}`);
        }

      } else {
        console.log(page);
        return Promise.reject('Błąd! Nie znaleziono numeru przesyłki Allegro / kodu kreskowego.');
      }
    } else {
      console.log('Inna etykieta');
    }
  });
}
